# Week 4 Capstone — End-to-End Sales Analysis

Analysis of the "Financial Sample" dataset (700 orders, Sep 2013 – Dec 2014): data cleaning, EDA, SQL/Pandas analysis,
a regression model to predict sales, an Excel workbook, a Power BI build kit and a PDF report.

## Contents
| Path | What it is |
|---|---|
| `capstone_analysis.ipynb` | Main Python notebook (cleaning → EDA → SQL & Pandas → regression → insights), executed with outputs |
| `Capstone_Excel_Analysis.xlsx` | Formula-driven Excel workbook: Summary, Analysis (tables + charts), Regression (+ calculator), Data |
| `Capstone_Final_Report.pdf` | Explanation report with charts, findings and recommendations |
| `Stakeholder_Summary.md` | One-page summary of findings and recommendations |
| `powerbi/` | Cleaned CSV, DAX measures and step-by-step guide for the Power BI dashboard (`.pbix` is built in Power BI Desktop) |
| `data/source/` | Original dataset as supplied (PDF export of the Google Sheet) |
| `data/raw_extracted.csv` | Table rebuilt from the PDF |
| `data/financial_sample_clean.csv` | Cleaned dataset used everywhere |
| `outputs/figures/`, `outputs/key_metrics.json` | Charts and metrics produced by the notebook |
| `src/` | Scripts: `extract_data.py`, `clean_data.py`, `build_notebook.py`, `build_excel.py`, `build_report.py` |

## Reproduce
```bash
pip install -r requirements.txt
python src/extract_data.py "data/source/Sample_data_1_xlsx_-_Google_Sheets.pdf" data/raw_extracted.csv
python src/build_notebook.py     # cleans data, runs the full analysis, writes the notebook + figures + metrics
python src/build_excel.py        # Excel workbook (recalculate in Excel/LibreOffice on first open)
python src/build_report.py       # PDF report
```
Or just open `capstone_analysis.ipynb` in Jupyter and run all cells (the notebook needs `data/raw_extracted.csv`).

## Data notes
- The dataset arrived as a PDF export; the table was rebuilt by position and clipped text (e.g. "Governmen") was restored.
- One order had blank Sales/COGS; both were reconstructed from Gross Sales, Discounts and Profit.
- After cleaning, all 700 rows satisfy: Units × Price = Gross Sales, Gross − Discounts = Sales, Sales − COGS = Profit.

## Headline results
Net sales $118.7M, profit $16.9M (14.2% margin). Government = 44% of sales / 67% of profit. Enterprise margin −3.1%
(all 58 loss-making orders). High-discount margin 9.1% vs 21.9% with no discount. Regression (Units × Price + discount band):
test R² = 0.997.
