"""Rebuild the 700-row 'Financial Sample' dataset from the PDF export of the Google Sheet.

The PDF printed the sheet in two halves: pages 1-21 hold columns Segment..COGS and
pages 22-42 hold columns Profit..Year, in the same row order. Segment/Country text is
clipped in the PDF ("Governmen", "United Sta"), so those are restored from known values.
"""
import re
import sys
import pdfplumber
import pandas as pd

PDF = sys.argv[1]
OUT = sys.argv[2]

PRODUCTS = ["Carretera", "Montana", "Paseo", "Velo", "VTT", "Amarilla"]
SEGMENTS = {
    "Governmen": "Government",
    "Midmarket": "Midmarket",
    "Channel Pa": "Channel Partners",
    "Channel": "Channel Partners",
    "Small Busin": "Small Business",
    "Small": "Small Business",
    "Enterprise": "Enterprise",
}
COUNTRIES = {
    "Canada": "Canada",
    "France": "France",
    "Germany": "Germany",
    "Mexico": "Mexico",
    "United Sta": "United States of America",
    "UnitedSta": "United States of America",
    "United": "United States of America",
}
BANDS = ["None", "Low", "Medium", "High"]

# right-edge x position of each numeric column on the left-hand pages
LEFT_EDGES = {
    "Units Sold": 330, "Manufacturing Price": 431, "Sale Price": 490,
    "Gross Sales": 552, "Discounts": 608, "Sales": 654, "COGS": 698,
}
LEFT_COLS_NUM = list(LEFT_EDGES)


def page_rows(pg):
    ws = pg.extract_words()
    rows = {}
    for w in ws:
        rows.setdefault(round(w["top"]), []).append(w)
    out = []
    for k in sorted(rows):
        out.append(sorted(rows[k], key=lambda w: w["x0"]))
    return out


def parse_left(words):
    # text before Discount Band column (x < 200) holds segment + country + product
    head = "".join(w["text"] if i == 0 else " " + w["text"]
                   for i, w in enumerate([w for w in words if w["x0"] < 200]))
    head_ns = head.replace(" ", "")
    product = next((p for p in PRODUCTS if head_ns.endswith(p)), None)
    rest = head_ns[: -len(product)] if product else head_ns
    seg = next((v for k, v in SEGMENTS.items() if rest.startswith(k.replace(" ", ""))), None)
    if seg:
        key = next(k for k in SEGMENTS if rest.startswith(k.replace(" ", "")))
        rest2 = rest[len(key.replace(" ", "")):]
    else:
        rest2 = rest
    country = next((v for k, v in COUNTRIES.items() if rest2.startswith(k.replace(" ", ""))), None)
    band = next((w["text"] for w in words if w["text"] in BANDS and 195 < w["x0"] < 275), None)
    rec = {"Segment": seg, "Country": country, "Product": product, "Discount Band": band}
    for w in words:
        if w["x0"] < 275:
            continue
        try:
            val = float(w["text"].replace(",", ""))
        except ValueError:
            continue
        col = min(LEFT_EDGES, key=lambda c: abs(LEFT_EDGES[c] - w["x1"]))
        if abs(LEFT_EDGES[col] - w["x1"]) < 14:
            rec[col] = val
    return rec


def parse_right(words):
    t = [w["text"] for w in words]
    m = re.fullmatch(r"(-?[\d.]+?)(1-[A-Z][a-z]{2}-\d{2})", t[0])
    if m:  # profit and date were printed without a gap
        t = [m.group(1), m.group(2)] + t[1:]
    profit = float(t[0].replace(",", ""))
    date = t[1]
    month_num = int(t[2])
    month_name = t[3]
    year = int(t[4])
    return {"Profit": profit, "Date": date, "Month Number": month_num,
            "Month Name": month_name, "Year": year}


with pdfplumber.open(PDF) as pdf:
    n = len(pdf.pages)
    left, right = [], []
    mode = "left"
    for i, pg in enumerate(pdf.pages):
        rows = page_rows(pg)
        if rows and rows[0] and rows[0][0]["text"] == "Profit":
            mode = "right"
        for r in rows:
            txt = " ".join(w["text"] for w in r)
            if txt.startswith("Segment Country") or txt.startswith("Profit Date"):
                continue
            if mode == "left":
                left.append(parse_left(r))
            else:
                right.append(parse_right(r))

print("left rows", len(left), "right rows", len(right))
assert len(left) == len(right), "halves do not align"
df = pd.concat([pd.DataFrame(left), pd.DataFrame(right)], axis=1)
df.to_csv(OUT, index=False)
print(df.isna().sum())
print(df.head())
