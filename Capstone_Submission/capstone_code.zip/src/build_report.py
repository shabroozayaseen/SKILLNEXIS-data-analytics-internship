"""Builds Capstone_Final_Report.pdf from outputs/key_metrics.json and outputs/figures/*.png"""
import json
from PIL import Image
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                PageBreak, Image as RLImage, KeepTogether)

M = json.load(open("outputs/key_metrics.json"))
K = M["kpi"]
seg = {r["Segment"]: r for r in M["by_segment"]}
band = {r["Discount Band"]: r for r in M["by_band"]}
models = {r["Model"]: r for r in M["models"]}
LFL = M["like_for_like"]
HIGH_ADJ = next(v for k, v in M["ols"]["coef"].items() if "High" in k)

NAVY, BLUE, LIGHT = colors.HexColor("#1F3A5F"), colors.HexColor("#2B6CB0"), colors.HexColor("#EAF1F8")
ss = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=ss["Heading1"], fontName="Helvetica-Bold", fontSize=16, textColor=NAVY, spaceBefore=6, spaceAfter=8)
H2 = ParagraphStyle("H2", parent=ss["Heading2"], fontName="Helvetica-Bold", fontSize=12, textColor=NAVY, spaceBefore=8, spaceAfter=4)
B = ParagraphStyle("B", parent=ss["BodyText"], fontName="Helvetica", fontSize=10, leading=14, alignment=TA_LEFT, spaceAfter=5)
SMALL = ParagraphStyle("S", parent=B, fontSize=8.5, leading=11, textColor=colors.HexColor("#555555"))
BUL = ParagraphStyle("BUL", parent=B, leftIndent=14, bulletIndent=2, spaceAfter=3)
TITLE = ParagraphStyle("T", parent=ss["Title"], fontName="Helvetica-Bold", fontSize=24, textColor=NAVY, alignment=TA_LEFT, spaceAfter=4)
SUB = ParagraphStyle("SUB", parent=B, fontSize=12, textColor=BLUE)
CELL = ParagraphStyle("C", parent=B, fontSize=8.5, leading=10.5, spaceAfter=0)

W = 6.9 * inch


def img(name, width=W):
    path = f"outputs/figures/{name}.png"
    w, h = Image.open(path).size
    return RLImage(path, width=width, height=width * h / w)


def bullets(items):
    return [Paragraph(t, BUL, bulletText="•") for t in items]


def table(data, col_widths=None, align_right_from=1, bold_last=False):
    t = Table(data, colWidths=col_widths, repeatRows=1)
    st = [("BACKGROUND", (0, 0), (-1, 0), BLUE), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
          ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 8.5),
          ("FONTNAME", (0, 1), (-1, -1), "Helvetica"), ("ALIGN", (align_right_from, 0), (-1, -1), "RIGHT"),
          ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
          ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#CCCCCC")),
          ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]
    if bold_last:
        st.append(("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"))
    t.setStyle(TableStyle(st))
    return t


def usd(x):
    return f"${x:,.0f}" if x >= 0 else f"-${abs(x):,.0f}"


def pct(x):
    return f"{x:.1f}%"


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#777777"))
    canvas.drawString(0.8 * inch, 0.5 * inch, "Data Analyst Course - Week 4 Capstone: End-to-End Sales Analysis")
    canvas.drawRightString(letter[0] - 0.8 * inch, 0.5 * inch, f"Page {doc.page}")
    canvas.restoreState()


doc = SimpleDocTemplate("Capstone_Final_Report.pdf", pagesize=letter, leftMargin=0.8 * inch, rightMargin=0.8 * inch,
                        topMargin=0.7 * inch, bottomMargin=0.8 * inch, title="Week 4 Capstone - Sales Analysis Report",
                        author="Data Analyst Course Capstone")
S = []

# ----- Page 1: title + executive summary
S += [Paragraph("End-to-End Sales Analysis", TITLE),
      Paragraph("Week 4 Capstone Project - Data Visualization &amp; Analysis Report", SUB), Spacer(1, 8),
      Paragraph("Executive summary", H1),
      Paragraph("This report analyses 700 orders (September 2013 to December 2014) across five customer segments, five "
                "countries and six products. It cleans the data, explores it, answers business questions with SQL and "
                "Pandas, builds a regression model to predict sales, and ends with recommendations for stakeholders.", B)]
kp = [["Metric", "Value"],
      ["Orders / units sold", f"{K['orders']:,} / {K['units']:,.0f}"],
      ["Net sales", usd(K["sales"])],
      ["Profit", f"{usd(K['profit'])}  ({pct(K['margin_pct'])} margin)"],
      ["Discounts given", f"{usd(K['discounts'])}  ({pct(K['discount_pct'])} of gross sales)"],
      ["Loss-making orders", f"{K['loss_orders']} orders, {usd(K['loss_amount'])}"]]
S += [table(kp, [2.3 * inch, 4.6 * inch]), Spacer(1, 8), Paragraph("What the data says", H2)]
S += bullets([
    f"<b>Government drives the business:</b> {pct(seg['Government']['Sales share %'])} of sales and "
    f"{pct(seg['Government']['Profit share %'])} of profit. Government plus Small Business is about 80% of sales.",
    f"<b>Enterprise loses money:</b> margin {pct(seg['Enterprise']['Margin %'])} ({usd(seg['Enterprise']['Profit'])} profit). "
    f"All {K['loss_orders']} loss-making orders are Enterprise orders.",
    f"<b>Discounts erode profit:</b> margin is {pct(band['None']['Margin %'])} with no discount but only "
    f"{pct(band['High']['Margin %'])} in the High band, yet High and Medium bands already carry "
    f"{pct(band['High']['Sales share %'] + band['Medium']['Sales share %'])} of sales.",
    "<b>Countries are balanced</b> ($21M-$25M each), so the profit problem is about segments and pricing, not geography.",
    f"<b>Seasonality:</b> October and December are the peak months. Like-for-like (Sep-Dec) sales grew "
    f"{LFL['growth_pct']:.0f}% in 2014 versus 2013.",
    f"<b>Prediction:</b> price, volume and discount band predict sales almost exactly (test R-squared "
    f"{models['B. Linear + Units x Price']['Test R2']:.3f}); without volume the model reaches only "
    f"{M['planning_model']['test_r2']:.2f}-{M['planning_model']['cv_r2']:.2f}, so forecasting volume is the key task.",
])
S += [Paragraph("Top recommendations", H2)]
S += bullets([
    "Fix Enterprise economics: raise price, cut unit cost or limit discounting so no order is sold below cost.",
    "Put approval gates on discounts above the Medium band.",
    "Protect Government, but reduce reliance on one segment for two-thirds of profit.",
    "Test scaling Channel Partners and Midmarket, which earn high margins on small sales bases.",
])
S.append(PageBreak())

# ----- Data & method
S += [Paragraph("1. Data and method", H1),
      Paragraph("The Google Sheet was supplied as a PDF export. It printed the columns in two halves (Segment to COGS, then "
                "Profit to Year), with some text clipped (for example \"Governmen\", \"United Sta\"). The table was rebuilt by "
                "reading each value by its position on the page and restoring the clipped text from the known categories.", B),
      Paragraph("Cleaning and validation", H2)]
cl = [["Check", "Result / action"],
      ["Rows and columns", "700 rows x 16 source columns (two derived columns added)"],
      ["Missing values", "1 order had blank Sales and COGS; rebuilt as Gross Sales - Discounts and Sales - Profit"],
      ["Category 'None' (Discount Band)", "Kept as a real category, not treated as missing"],
      ["Dates", "Text such as 1-Dec-14 converted to dates; month and year columns match the date"],
      ["Arithmetic integrity", "Units x Price = Gross Sales, Gross - Discounts = Sales, Sales - COGS = Profit: all 700 rows pass"],
      ["Duplicates", "None"],
      ["New fields", "Profit Margin % and Discount %"]]
cl = [[Paragraph(str(c), CELL) for c in row] for row in cl]
t = table(cl, [2.1 * inch, 4.8 * inch], align_right_from=9)
S += [t, Spacer(1, 6),
      Paragraph("Tools: Python (pandas, matplotlib, seaborn, scikit-learn, statsmodels), SQLite for SQL queries, an Excel "
                "workbook with formula-driven summaries, and a Power BI dashboard built from the same cleaned data.", B),
      Paragraph("2. Exploratory analysis", H1), img("02_segment_sales_profit_margin"),
      Paragraph("Government and Small Business generate most sales. Enterprise sells $19.6M but loses money; Channel "
                "Partners and Midmarket have the best margins on very small sales.", B)]
S.append(PageBreak())

rows = [["Segment", "Orders", "Sales", "Profit", "Margin", "Sales share", "Profit share"]]
for r in M["by_segment"]:
    rows.append([r["Segment"], f"{r['Orders']}", usd(r["Sales"]), usd(r["Profit"]), pct(r["Margin %"]),
                 pct(r["Sales share %"]), pct(r["Profit share %"])])
S += [Paragraph("Segment performance (SQL and Pandas agree)", H2), table(rows, [1.4 * inch, 0.6 * inch, 1.2 * inch, 1.1 * inch, 0.8 * inch, 0.9 * inch, 0.9 * inch]),
      Spacer(1, 8), img("04_discount_band"),
      Paragraph("Margins fall steadily as discount depth rises. The High band earns less than half the margin of the "
                "no-discount band while carrying almost a third of all sales.", B),
      img("05_monthly_sales"),
      Paragraph("2013 contains only September to December, so the large 2014 total partly reflects extra months. "
                f"Comparing the same four months gives growth of {LFL['growth_pct']:.0f}%.", B)]
S.append(PageBreak())
S += [img("06_profit_distribution_losses"),
      Paragraph(f"Every one of the {K['loss_orders']} orders with negative profit comes from the Enterprise segment, "
                f"together losing {usd(K['loss_amount'])}. Enterprise cost of goods sold is about 103% of its net sales.", B),
      img("08_margin_heatmap", 5.6 * inch),
      Paragraph("Enterprise is red in every discount band, so the issue is pricing against cost, not only discounting. "
                "Government remains healthy even at high discount levels.", B)]
S.append(PageBreak())

# ----- Regression
S += [Paragraph("3. Regression model: predicting sales", H1),
      Paragraph("<b>Target:</b> Sales per order. <b>Features:</b> Units Sold, Sale Price, Discount Band, Segment, Country, "
                "Product, Month and Year. Gross Sales, Discounts, COGS and Profit were excluded because they are calculated "
                "from sales and would leak the answer. Models were scored on a held-out 20% test set and with 5-fold "
                "cross-validation.", B)]
mr = [["Model", "Test R-sq", "CV R-sq", "MAE ($)", "RMSE ($)"]]
for r in M["models"]:
    mr.append([r["Model"], f"{r['Test R2']:.4f}", f"{r['CV R2 (mean)']:.4f}", f"{r['MAE ($)']:,.0f}", f"{r['RMSE ($)']:,.0f}"])
S += [table(mr, [2.6 * inch, 1.0 * inch, 1.0 * inch, 1.1 * inch, 1.2 * inch]), Spacer(1, 6),
      Paragraph(f"The raw-feature linear model explains {models['A. Linear (raw features)']['Test R2']*100:.0f}% of the variation. "
                "Adding one engineered feature, Units x Sale Price (list-price revenue), lifts this to "
                f"{models['B. Linear + Units x Price']['Test R2']*100:.1f}%, matching the tree models while staying fully "
                "explainable. It is the recommended model.", B),
      img("09_actual_vs_predicted"),
      Paragraph("Interpretation and limits", H2)]
S += bullets([
    f"Each $1 of list-price revenue converts to about ${M['ols']['coef']['Expected_Gross']:.2f} of net sales on average; "
    f"the High band shifts predictions down by roughly {usd(abs(HIGH_ADJ))} per order.",
    "The model is largely recovering the pricing formula (price x volume less discount), so it is only as good as the "
    "volume figure it is given.",
    f"A planning model without volume reaches test R-squared {M['planning_model']['test_r2']:.2f} "
    f"(cross-validated {M['planning_model']['cv_r2']:.2f}); Sale Price dominates. Forecasting units is therefore the next step.",
    "Only 16 months and 700 orders are available, so seasonality estimates are based on one year of full data.",
])
S += [img("10_feature_importance", 5.2 * inch)]

# ----- Recommendations
S += [Paragraph("4. Recommendations", H1)]
recs = [
    ("Fix Enterprise economics", "Raise list prices, lower unit cost or limit discounts so that no order is sold below cost. "
                                  f"Break-even alone would recover about {usd(abs(seg['Enterprise']['Profit']))} of profit."),
    ("Govern discounting", "Require approval for discounts above the Medium band and steer High-band deals toward Low. "
                           "High-band margin is less than half the no-discount margin."),
    ("Protect Government, diversify", "Government delivers two-thirds of profit; losing a few large deals would hurt. "
                                      "Grow Midmarket and Small Business margins to balance the mix."),
    ("Test scaling Channel Partners and Midmarket", "73% and 28% margins on small sales bases are attractive; validate that "
                                                    "margins hold at higher volume before committing investment."),
    ("Plan around seasonality", "Stock and promote for the October and December peaks."),
    ("Forecast volume", "Build a units forecast by segment and month and feed it into the price x discount model."),
]
for i, (h, d) in enumerate(recs, 1):
    S.append(Paragraph(f"<b>{i}. {h}.</b> {d}", B))
S += [Spacer(1, 10), Paragraph("Deliverables", H2)]
S += bullets([
    "capstone_analysis.ipynb - cleaning, EDA, SQL/Pandas analysis and regression (Python notebook)",
    "Capstone_Excel_Analysis.xlsx - formula-driven summaries, charts, regression results and calculator (Excel)",
    "powerbi/ - cleaned CSV, DAX measures and a step-by-step build guide for the Power BI dashboard (.pbix is built in Power BI Desktop)",
    "Capstone_Final_Report.pdf - this explanation report",
    "capstone_code.zip - all code and data used",
])

doc.build(S, onFirstPage=footer, onLaterPages=footer)
print("saved Capstone_Final_Report.pdf")
