"""Clean the extracted dataset and save it as CSV (for Power BI / Python) ."""
import sys
import pandas as pd

RAW, OUT = sys.argv[1], sys.argv[2]

# keep_default_na=False: the Discount Band value "None" is a real category, not a missing value
df = pd.read_csv(RAW, keep_default_na=False, na_values=[""])

df["Date"] = pd.to_datetime(df["Date"], format="%d-%b-%y")

# Row 212 lost Sales/COGS in the PDF export; both are exactly derivable
miss = df["Sales"].isna() | df["COGS"].isna()
df.loc[miss, "Sales"] = df.loc[miss, "Gross Sales"] - df.loc[miss, "Discounts"]
df.loc[miss, "COGS"] = df.loc[miss, "Sales"] - df.loc[miss, "Profit"]
print("rows repaired:", int(miss.sum()))

# consistency checks
assert ((df["Units Sold"] * df["Sale Price"] - df["Gross Sales"]).abs() < 1).all()
assert ((df["Gross Sales"] - df["Discounts"] - df["Sales"]).abs() < 1).all()
assert ((df["Sales"] - df["COGS"] - df["Profit"]).abs() < 1).all()
assert (df["Month Number"] == df["Date"].dt.month).all()
assert (df["Year"] == df["Date"].dt.year).all()
assert df.isna().sum().sum() == 0

df["Profit Margin %"] = (df["Profit"] / df["Sales"] * 100).round(2)
df["Discount %"] = (df["Discounts"] / df["Gross Sales"] * 100).round(2)
df.to_csv(OUT, index=False, date_format="%Y-%m-%d")
print(df.shape, "saved ->", OUT)
print(df["Discount Band"].value_counts().to_dict())
print(df["Segment"].value_counts().to_dict())
print(df["Country"].value_counts().to_dict())
print(df["Product"].value_counts().to_dict())
print("Total Sales", round(df.Sales.sum(), 2), "Total Profit", round(df.Profit.sum(), 2))
