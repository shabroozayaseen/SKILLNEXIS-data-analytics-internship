"""Builds Capstone_Excel_Analysis.xlsx (formula-driven) from the cleaned CSV + notebook metrics."""
import json
import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

OUT = "Capstone_Excel_Analysis.xlsx"
df = pd.read_csv("data/financial_sample_clean.csv", keep_default_na=False)
df["Date"] = pd.to_datetime(df["Date"])
M = json.load(open("outputs/key_metrics.json"))

F = "Arial"
f_norm = Font(name=F, size=10)
f_bold = Font(name=F, size=10, bold=True)
f_head = Font(name=F, size=10, bold=True, color="FFFFFF")
f_title = Font(name=F, size=16, bold=True, color="1F3A5F")
f_sub = Font(name=F, size=10, italic=True, color="666666")
f_input = Font(name=F, size=10, color="0000FF")
fill_head = PatternFill("solid", fgColor="2B6CB0")
fill_kpi = PatternFill("solid", fgColor="EAF1F8")
fill_input = PatternFill("solid", fgColor="FFFF99")
thin = Side(style="thin", color="CCCCCC")
box = Border(left=thin, right=thin, top=thin, bottom=thin)

USD = '$#,##0;($#,##0);-'
PCT = '0.0%;(0.0%);-'
NUM = '#,##0;(#,##0);-'

wb = Workbook()

# ------------------------------------------------------------------ Data sheet
wsD = wb.active
wsD.title = "Data"
cols = list(df.columns)  # Segment..COGS, Profit, Date, Month Number, Month Name, Year, Profit Margin %, Discount %
hdr = cols
wsD.append(hdr)
for r in df.itertuples(index=False):
    wsD.append(list(r))
n = len(df)
last = n + 1
ci = {c: get_column_letter(i + 1) for i, c in enumerate(cols)}
# derived columns as live formulas (fractions, shown as %)
for r in range(2, last + 1):
    wsD[f"{ci['Profit Margin %']}{r}"] = f"=IF({ci['Sales']}{r}=0,0,{ci['Profit']}{r}/{ci['Sales']}{r})"
    wsD[f"{ci['Discount %']}{r}"] = f"=IF({ci['Gross Sales']}{r}=0,0,{ci['Discounts']}{r}/{ci['Gross Sales']}{r})"
    wsD[f"{ci['Date']}{r}"].number_format = "yyyy-mm-dd"
    for c in ["Gross Sales", "Discounts", "Sales", "COGS", "Profit"]:
        wsD[f"{ci[c]}{r}"].number_format = '#,##0.00;(#,##0.00);-'
    wsD[f"{ci['Profit Margin %']}{r}"].number_format = "0.0%"
    wsD[f"{ci['Discount %']}{r}"].number_format = "0.0%"
for c in range(1, len(cols) + 1):
    wsD.cell(1, c).font = f_head
    wsD.cell(1, c).fill = fill_head
    wsD.cell(1, c).alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    wsD.column_dimensions[get_column_letter(c)].width = 16 if c > 4 else 22
for row in wsD.iter_rows(min_row=2, max_row=last):
    for cell in row:
        cell.font = f_norm
wsD.row_dimensions[1].height = 32
wsD.freeze_panes = "A2"
tab = Table(displayName="SalesData", ref=f"A1:{get_column_letter(len(cols))}{last}")
tab.tableStyleInfo = TableStyleInfo(name="TableStyleLight9", showRowStripes=True)
wsD.add_table(tab)


def rng(col):
    return f"Data!${ci[col]}$2:${ci[col]}${last}"


# ------------------------------------------------------------------ Analysis sheet
wsA = wb.create_sheet("Analysis")
wsA["A1"] = "Sales & Profit Analysis (all figures are live formulas on the Data sheet)"
wsA["A1"].font = f_title
wsA["A2"] = "Margin % = Profit / Sales.  Share % = row total / grand total."
wsA["A2"].font = f_sub
heads = ["", "Orders", "Units Sold", "Sales", "Profit", "Margin %", "Sales Share %", "Profit Share %"]


def block(title, start_row, key_col, items, extra_filter=None):
    """Writes a SUMIFS block, returns (first_data_row, last_data_row)."""
    wsA.cell(start_row, 1, title).font = Font(name=F, size=12, bold=True, color="1F3A5F")
    hr = start_row + 1
    for j, h in enumerate(heads, start=1):
        c = wsA.cell(hr, j, h if j > 1 else key_col)
        c.font, c.fill, c.alignment, c.border = f_head, fill_head, Alignment(horizontal="center"), box
    r0 = hr + 1
    for i, it in enumerate(items):
        r = r0 + i
        wsA.cell(r, 1, it).font = f_norm
        crit = f"$A{r}"
        wsA.cell(r, 2, f"=COUNTIFS({rng(key_col)},{crit})")
        wsA.cell(r, 3, f"=SUMIFS({rng('Units Sold')},{rng(key_col)},{crit})")
        wsA.cell(r, 4, f"=SUMIFS({rng('Sales')},{rng(key_col)},{crit})")
        wsA.cell(r, 5, f"=SUMIFS({rng('Profit')},{rng(key_col)},{crit})")
    r1 = r0 + len(items) - 1
    tr = r1 + 1
    wsA.cell(tr, 1, "Total").font = f_bold
    for j, col in enumerate("BCDE", start=2):
        wsA.cell(tr, j, f"=SUM({col}{r0}:{col}{r1})")
    for r in range(r0, tr + 1):
        wsA.cell(r, 6, f"=IF(D{r}=0,0,E{r}/D{r})")
        wsA.cell(r, 7, f"=IF(D${tr}=0,0,D{r}/D${tr})")
        wsA.cell(r, 8, f"=IF(E${tr}=0,0,E{r}/E${tr})")
        for j in range(1, 9):
            c = wsA.cell(r, j)
            c.border = box
            c.font = f_bold if r == tr else f_norm
            if j == 2 or j == 3:
                c.number_format = NUM
            elif j in (4, 5):
                c.number_format = USD
            elif j >= 6:
                c.number_format = PCT
    return r0, r1, tr


segs = [r["Segment"] for r in M["by_segment"]]
ctrs = [r["Country"] for r in M["by_country"]]
prods = [r["Product"] for r in M["by_product"]]
bands = ["None", "Low", "Medium", "High"]

s0, s1, st = block("1. Performance by Segment", 4, "Segment", segs)
c0, c1, ct = block("2. Performance by Country", st + 3, "Country", ctrs)
p0, p1, pt = block("3. Performance by Product", ct + 3, "Product", prods)
b0, b1, bt = block("4. Performance by Discount Band", pt + 3, "Discount Band", bands)

# monthly block (needs Year + Month Number)
mr = bt + 3
wsA.cell(mr, 1, "5. Monthly trend").font = Font(name=F, size=12, bold=True, color="1F3A5F")
for j, h in enumerate(["Month", "Year", "Month No.", "Orders", "Sales", "Profit", "Margin %"], start=1):
    c = wsA.cell(mr + 1, j, h)
    c.font, c.fill, c.alignment, c.border = f_head, fill_head, Alignment(horizontal="center"), box
months = [(2013, m) for m in range(9, 13)] + [(2014, m) for m in range(1, 13)]
m0 = mr + 2
import calendar
for i, (y, mo) in enumerate(months):
    r = m0 + i
    wsA.cell(r, 1, f"{calendar.month_abbr[mo]} {str(y)[2:]}")
    wsA.cell(r, 2, y)
    wsA.cell(r, 3, mo)
    wsA.cell(r, 4, f"=COUNTIFS({rng('Year')},B{r},{rng('Month Number')},C{r})")
    wsA.cell(r, 5, f"=SUMIFS({rng('Sales')},{rng('Year')},B{r},{rng('Month Number')},C{r})")
    wsA.cell(r, 6, f"=SUMIFS({rng('Profit')},{rng('Year')},B{r},{rng('Month Number')},C{r})")
    wsA.cell(r, 7, f"=IF(E{r}=0,0,F{r}/E{r})")
    for j in range(1, 8):
        c = wsA.cell(r, j)
        c.font, c.border = f_norm, box
        c.number_format = {4: NUM, 5: USD, 6: USD, 7: PCT}.get(j, "General")
m1 = m0 + len(months) - 1
wsA.cell(m1 + 1, 1, "Total").font = f_bold
for j, col in [(4, "D"), (5, "E"), (6, "F")]:
    c = wsA.cell(m1 + 1, j, f"=SUM({col}{m0}:{col}{m1})")
    c.font, c.border = f_bold, box
    c.number_format = NUM if j == 4 else USD
wsA.cell(m1 + 1, 7, f"=IF(E{m1+1}=0,0,F{m1+1}/E{m1+1})").number_format = PCT
wsA.cell(m1 + 1, 7).font = f_bold
wsA.cell(m1 + 1, 7).border = box
wsA.cell(m1 + 3, 1, "Note: 2013 contains only Sep-Dec, so full-year comparisons across 2013 and 2014 are not like-for-like.").font = f_sub

# like-for-like (live formulas)
lr = m1 + 5
wsA.cell(lr, 1, "6. Like-for-like comparison (Sep-Dec only)").font = Font(name=F, size=12, bold=True, color="1F3A5F")
for j, h in enumerate(["", "Sales", "Profit"], start=1):
    c = wsA.cell(lr + 1, j, h)
    c.font, c.fill, c.border = f_head, fill_head, box
wsA.cell(lr + 2, 1, "Sep-Dec 2013")
wsA.cell(lr + 3, 1, "Sep-Dec 2014")
wsA.cell(lr + 2, 2, f"=SUMIFS(E{m0}:E{m1},B{m0}:B{m1},2013,C{m0}:C{m1},\">=9\")")
wsA.cell(lr + 3, 2, f"=SUMIFS(E{m0}:E{m1},B{m0}:B{m1},2014,C{m0}:C{m1},\">=9\")")
wsA.cell(lr + 2, 3, f"=SUMIFS(F{m0}:F{m1},B{m0}:B{m1},2013,C{m0}:C{m1},\">=9\")")
wsA.cell(lr + 3, 3, f"=SUMIFS(F{m0}:F{m1},B{m0}:B{m1},2014,C{m0}:C{m1},\">=9\")")
wsA.cell(lr + 4, 1, "Growth %").font = f_bold
wsA.cell(lr + 4, 2, f"=IF(B{lr+2}=0,0,B{lr+3}/B{lr+2}-1)")
wsA.cell(lr + 4, 3, f"=IF(C{lr+2}=0,0,C{lr+3}/C{lr+2}-1)")
for r in range(lr + 2, lr + 5):
    for j in range(1, 4):
        c = wsA.cell(r, j)
        c.font = f_bold if r == lr + 4 else f_norm
        c.border = box
        c.number_format = PCT if r == lr + 4 else USD

wsA.column_dimensions["A"].width = 26
for col in "BCDEFGH":
    wsA.column_dimensions[col].width = 16
wsA.sheet_view.showGridLines = False

# charts (placed to the right of the tables)
def bar(title, cats, vals, anchor, ytitle, colors=None, w=17, h=7.5):
    ch = BarChart()
    ch.type = "col"
    ch.title = title
    ch.height, ch.width = h, w
    ch.add_data(vals, titles_from_data=True)
    ch.set_categories(cats)
    ch.y_axis.title = ytitle
    ch.y_axis.majorGridlines = None
    ch.legend.position = "b"
    ch.y_axis.delete = False
    ch.x_axis.delete = False
    wsA.add_chart(ch, anchor)
    return ch

bar("Sales and Profit by Segment", Reference(wsA, min_col=1, min_row=s0, max_row=s1),
    Reference(wsA, min_col=4, max_col=5, min_row=s0 - 1, max_row=s1), "J4", "USD")
ch = BarChart(); ch.type = "col"; ch.title = "Profit Margin % by Segment"; ch.height, ch.width = 7.5, 17
ch.add_data(Reference(wsA, min_col=6, min_row=s0 - 1, max_row=s1), titles_from_data=True)
ch.set_categories(Reference(wsA, min_col=1, min_row=s0, max_row=s1))
ch.y_axis.number_format = "0%"; ch.y_axis.majorGridlines = None; ch.legend = None
ch.y_axis.delete = False; ch.x_axis.delete = False
wsA.add_chart(ch, "J20")
bar("Sales by Country", Reference(wsA, min_col=1, min_row=c0, max_row=c1),
    Reference(wsA, min_col=4, min_row=c0 - 1, max_row=c1), "J36", "USD").y_axis.scaling.min = 0
bar("Sales by Product", Reference(wsA, min_col=1, min_row=p0, max_row=p1),
    Reference(wsA, min_col=4, min_row=p0 - 1, max_row=p1), "J52", "USD").y_axis.scaling.min = 0
ch = BarChart(); ch.type = "col"; ch.title = "Profit Margin % by Discount Band"; ch.height, ch.width = 7.5, 17
ch.add_data(Reference(wsA, min_col=6, min_row=b0 - 1, max_row=b1), titles_from_data=True)
ch.set_categories(Reference(wsA, min_col=1, min_row=b0, max_row=b1))
ch.y_axis.number_format = "0%"; ch.y_axis.majorGridlines = None; ch.legend = None
ch.y_axis.delete = False; ch.x_axis.delete = False
wsA.add_chart(ch, "J68")
lc = LineChart(); lc.title = "Monthly Sales"; lc.height, lc.width = 7.5, 17
lc.add_data(Reference(wsA, min_col=5, min_row=mr + 1, max_row=m1), titles_from_data=True)
lc.set_categories(Reference(wsA, min_col=1, min_row=m0, max_row=m1))
lc.y_axis.majorGridlines = None; lc.legend = None
lc.y_axis.delete = False; lc.x_axis.delete = False
wsA.add_chart(lc, "J84")

# ------------------------------------------------------------------ Regression sheet
wsR = wb.create_sheet("Regression")
wsR["A1"] = "Regression model to predict Sales"
wsR["A1"].font = f_title
wsR["A2"] = ("Models were fitted in Python (capstone_analysis.ipynb): 80/20 train/test split plus 5-fold cross-validation. "
             "Gross Sales, Discounts, COGS and Profit were excluded (they are derived from Sales).")
wsR["A2"].font = f_sub
for j, h in enumerate(["Model", "Test R²", "CV R² (mean)", "CV R² (std)", "MAE ($)", "RMSE ($)"], start=1):
    c = wsR.cell(4, j, h)
    c.font, c.fill, c.border, c.alignment = f_head, fill_head, box, Alignment(horizontal="center")
for i, r in enumerate(M["models"]):
    row = 5 + i
    vals = [r["Model"], r["Test R2"], r["CV R2 (mean)"], r["CV R2 (std)"], r["MAE ($)"], r["RMSE ($)"]]
    for j, v in enumerate(vals, start=1):
        c = wsR.cell(row, j, v)
        c.font, c.border = f_input if j > 1 else f_norm, box
        c.number_format = {2: "0.0000", 3: "0.0000", 4: "0.0000", 5: "#,##0", 6: "#,##0"}.get(j, "General")
wsR.cell(10, 1, "Blue = values pasted from the Python run (hardcoded model results). Chosen model: B. Linear + Units x Price (highest test R², simplest to explain).").font = f_sub
wsR.cell(11, 1, f"Planning model without Units Sold (Gradient Boosting): test R² = {M['planning_model']['test_r2']:.2f}, CV R² = {M['planning_model']['cv_r2']:.2f}. Sale Price is the dominant driver.").font = f_sub

# OLS coefficients and a working calculator
coef = M["ols"]["coef"]
wsR["A13"] = "Prediction calculator (OLS fitted on the training rows)"
wsR["A13"].font = Font(name=F, size=12, bold=True, color="1F3A5F")
wsR["A14"] = "Predicted Sales = Intercept + β × (Units × Sale Price) + band adjustment"
wsR["A14"].font = f_sub
rows = [("Intercept", coef["Intercept"]), ("β on Units × Sale Price", coef["Expected_Gross"]),
        ("Band adjustment: None", 0.0), ("Band adjustment: Low", coef["C(Band, Treatment('None'))[T.Low]"]),
        ("Band adjustment: Medium", coef["C(Band, Treatment('None'))[T.Medium]"]),
        ("Band adjustment: High", coef["C(Band, Treatment('None'))[T.High]"])]
for i, (k, v) in enumerate(rows):
    wsR.cell(15 + i, 1, k).font = f_norm
    c = wsR.cell(15 + i, 2, v)
    c.font = f_input
    c.number_format = "#,##0.0000" if "β" in k else "#,##0.00"
wsR["A22"] = "Your inputs (edit the yellow cells)"
wsR["A22"].font = f_bold
for r, (k, v) in zip(range(23, 26), [("Units Sold", 1000), ("Sale Price ($)", 300), ("Discount Band (None/Low/Medium/High)", "Medium")]):
    wsR.cell(r, 1, k).font = f_norm
    c = wsR.cell(r, 2, v)
    c.font, c.fill = f_input, fill_input
wsR["A26"] = "Predicted Sales ($)"
wsR["A26"].font = f_bold
wsR["B26"] = ('=B15+B16*B23*B24+INDEX(B17:B20,MATCH(B25,{"None","Low","Medium","High"},0))')
wsR["B26"].number_format = USD
wsR["B26"].font = f_bold
wsR["C26"] = "Example row: 1,000 units × $300, Medium band."
wsR["C26"].font = f_sub
wsR.column_dimensions["A"].width = 44
for col in "BCDEF":
    wsR.column_dimensions[col].width = 16
wsR.sheet_view.showGridLines = False

# ------------------------------------------------------------------ Summary sheet (first tab)
wsS = wb.create_sheet("Summary", 0)
wsS.sheet_view.showGridLines = False
wsS["A1"] = "Week 4 Capstone — Sales Analysis Summary"
wsS["A1"].font = f_title
wsS["A2"] = "Source: Financial Sample dataset (700 orders, Sep 2013 – Dec 2014). KPI values are formulas on the Data sheet."
wsS["A2"].font = f_sub
kp = [("Orders", f"=COUNTA({rng('Segment')})", NUM), ("Units Sold", f"=SUM({rng('Units Sold')})", NUM),
      ("Gross Sales", f"=SUM({rng('Gross Sales')})", USD), ("Discounts", f"=SUM({rng('Discounts')})", USD),
      ("Net Sales", f"=SUM({rng('Sales')})", USD), ("COGS", f"=SUM({rng('COGS')})", USD),
      ("Profit", f"=SUM({rng('Profit')})", USD), ("Profit margin", "=B10/B9", PCT),
      ("Discount rate (of gross)", "=B7/B6", PCT),
      ("Loss-making orders", f'=COUNTIF({rng("Profit")},"<0")', NUM),
      ("Total loss on those orders", f'=SUMIF({rng("Profit")},"<0")', USD)]
wsS["A4"] = "Key metrics"
wsS["A4"].font = Font(name=F, size=12, bold=True, color="1F3A5F")
# rows: 5.. so Gross Sales=B7? align references below
keymap_rows = {}
for i, (k, fml, fmt) in enumerate(kp):
    r = 5 + i
    keymap_rows[k] = r
    wsS.cell(r, 1, k).font = f_bold
    wsS.cell(r, 1).fill = fill_kpi
    c = wsS.cell(r, 2, fml)
    c.number_format, c.font, c.fill, c.border = fmt, f_norm, fill_kpi, box
# fix the dependent formulas to real row numbers
R = keymap_rows
wsS.cell(R["Profit margin"], 2, f"=B{R['Profit']}/B{R['Net Sales']}")
wsS.cell(R["Discount rate (of gross)"], 2, f"=B{R['Discounts']}/B{R['Gross Sales']}")
wsS.column_dimensions["A"].width = 30
wsS.column_dimensions["B"].width = 20
wsS.column_dimensions["C"].width = 4
wsS.column_dimensions["D"].width = 110

txt_r = 4
wsS["D4"] = "Findings"
wsS["D4"].font = Font(name=F, size=12, bold=True, color="1F3A5F")
findings = [
    "1. Government is 44% of sales and 67% of profit; with Small Business it makes up ~80% of sales.",
    "2. Enterprise loses money: −3.1% margin (−$0.61M profit). All 58 loss-making orders (−$0.78M) are Enterprise; its COGS is ~103% of net sales.",
    "3. Discounts erode profit: margin is 21.9% with no discount, 17.9% low, 14.4% medium and 9.1% high — yet High+Medium carry 64% of sales.",
    "4. Countries are balanced ($21M–$25M each); the profit gap is a segment/pricing issue, not a geography issue.",
    "5. October and December are peak months. 2013 covers Sep–Dec only; like-for-like Sep–Dec sales grew ~37% in 2014 (see Analysis, table 6).",
    "6. Sales is predicted almost exactly from price × volume × discount band (test R² = 0.997). Without volume, R² is only ~0.55–0.62: forecast volume first.",
]
for i, t in enumerate(findings):
    c = wsS.cell(5 + i, 4, t)
    c.font = f_norm
    c.alignment = Alignment(wrap_text=True, vertical="top")
    wsS.row_dimensions[5 + i].height = 30
wsS["D12"] = "Recommendations"
wsS["D12"].font = Font(name=F, size=12, bold=True, color="1F3A5F")
recs = [
    "1. Fix Enterprise economics: raise list price, cut unit cost or limit discounting so no order is sold below cost.",
    "2. Require approval for discounts above the Medium band and steer High-band volume toward Low.",
    "3. Protect Government but reduce dependence on a single segment (two-thirds of profit).",
    "4. Test scaling Channel Partners (73% margin) and Midmarket (28%) — small sales bases today.",
    "5. Plan inventory and promotions around the October/December peaks.",
    "6. Forecast units by segment and month, then apply the price × discount model to forecast sales.",
]
for i, t in enumerate(recs):
    c = wsS.cell(13 + i, 4, t)
    c.font = f_norm
    c.alignment = Alignment(wrap_text=True, vertical="top")
    wsS.row_dimensions[13 + i].height = 30
wsS["A18"] = "Sheets: Summary · Analysis (tables + charts) · Regression (model results + calculator) · Data (cleaned, 700 rows)"
wsS["A18"].font = f_sub
wsS["A19"] = "Data note: dataset rebuilt from a PDF export; one order's Sales/COGS were reconstructed from Gross Sales, Discounts and Profit."
wsS["A19"].font = f_sub

wb.move_sheet("Data", offset=len(wb.sheetnames) - 1 - wb.sheetnames.index("Data"))
wb.active = 0
wb.save(OUT)
print("saved", OUT)
